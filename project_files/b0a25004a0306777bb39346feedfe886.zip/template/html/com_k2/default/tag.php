<?php
/**
 * @version		2.6.x
 * @package		K2
 * @author		JoomlaWorks http://www.joomlaworks.net
 * @copyright	Copyright (c) 2006 - 2014 JoomlaWorks Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 */

// no direct access
defined('_JEXEC') or die;

?>
<!-- Start K2 Tag Layout -->
<div id="k2Container" class="tagView itemListView <?php if($this->params->get('pageclass_sfx')) echo ' '.$this->params->get('pageclass_sfx'); ?>">

	<?php if($this->params->get('show_page_title')): ?>
	<!-- Page title -->
	<div class="componentheading<?php echo $this->params->get('pageclass_sfx')?>">
		<?php echo $this->escape($this->params->get('page_title')); ?>
	</div>
	<?php endif; ?>

	<?php if($this->params->get('tagFeedIcon',1)): ?>
	<!-- RSS feed icon -->
	<div class="k2FeedIcon">
		<a href="<?php echo $this->feed; ?>" title="<?php echo JText::_('K2_SUBSCRIBE_TO_THIS_RSS_FEED'); ?>">
			<span><?php echo JText::_('K2_SUBSCRIBE_TO_THIS_RSS_FEED'); ?></span>
		</a>
		<div class="clr"></div>
	</div>
	<?php endif; ?>

	<?php if(count($this->items)): ?>
	<div class="tagItemList">
		<?php foreach($this->items as $item): ?>
		<div class="catItemView">
			<?php if($item->params->get('tagItemDateCreated',1)): ?>
			<div class="catItemdate">
				<!-- Date created -->
				<div class="catItemDateCreated">
					<span class="post_main_date"><?php echo JHTML::_('date', $item->created , 'd'); ?></span>
					<span class="post_main_month"><?php echo JHTML::_('date', $item->created , 'M, Y'); ?></span>
				</div>
				<div class="catItemType">
					<?php if($item->params->get('catItemImage') && !empty($item->image)): ?>
						<i class="fa fa-photo"></i>
					<?php elseif($item->params->get('catItemVideo') && !empty($item->video)): ?>
						<i class="fa fa-play-circle"></i>
					<?php elseif($item->params->get('catItemImageGallery') && !empty($item->gallery)): ?>
						<i class="fa fa-file-picture-o"></i>
					<?php else: ?>
						<i class="fa fa-file-text"></i>
					<?php endif;?>
				</div>
			</div>
			 <?php endif; ?>
			<div class="catItemInfo">
				<?php if($item->params->get('tagItemImage',1) && !empty($item->imageGeneric)): ?>
				  <!-- Item Image -->
				<div class="catItemImageBlock">
				  <span class="catItemImage">
					<a href="<?php echo $item->link; ?>" title="<?php if(!empty($item->image_caption)) echo K2HelperUtilities::cleanHtml($item->image_caption); else echo K2HelperUtilities::cleanHtml($item->title); ?>">
						<img src="<?php echo $item->imageXLarge; ?>" alt="<?php if(!empty($item->image_caption)) echo K2HelperUtilities::cleanHtml($item->image_caption); else echo K2HelperUtilities::cleanHtml($item->title); ?>" style="width:100%; height:auto;" />
					</a>
				  </span>
				</div>
				<!-- Item video -->
				<?php endif; ?>
	
				<div class="catItemContent">
					<?php if($item->params->get('tagItemIntroText',1)): ?>
					  <!-- Item introtext -->
						<div class="catItemIntroText">
							<?php echo $item->introtext; ?>
						</div>
					 <?php endif; ?>
					 <?php if ($item->params->get('tagItemReadMore')): ?>
					<!-- Item "read more..." link -->
					<div class="catItemButton">
						<div class="catItemReadMore">
							<a class="vina-readmore" href="<?php echo $item->link; ?>">
								<?php echo JText::_('K2_READ_MORE'); ?>
							</a>
						</div>
					</div>
					<?php endif; ?>
				</div>
			</div>
			
			
		</div>
		<?php endforeach; ?>
	</div>

	<!-- Pagination -->
	<?php if($this->pagination->getPagesLinks()): ?>
	<div class="k2Pagination">
		<?php echo $this->pagination->getPagesLinks(); ?>
	</div>
	<?php endif; ?>

	<?php endif; ?>
	
</div>
<!-- End K2 Tag Layout -->
