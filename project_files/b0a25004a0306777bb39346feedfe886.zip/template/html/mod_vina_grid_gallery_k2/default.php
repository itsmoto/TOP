<?php
/*
# ------------------------------------------------------------------------
# Vina Item Grid Gallery for K2 for Joomla 3
# ------------------------------------------------------------------------
# Copyright(C) 2014 www.VinaGecko.com. All Rights Reserved.
# @license http://www.gnu.org/licenseses/gpl-3.0.html GNU/GPL
# Author: VinaGecko.com
# Websites: http://vinagecko.com
# Forum: http://vinagecko.com/forum/
# ------------------------------------------------------------------------
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

$doc = JFactory::getDocument();
$doc->addScript('modules/mod_vina_grid_gallery_k2/assets/js/freewall.js', 'text/javascript');
$doc->addStyleSheet('modules/mod_vina_grid_gallery_k2/assets/css/style.css');
?>
<style type="text/css" scoped>
#vina-gridgallery-k2-wrapper<?php echo $module->id; ?> {
	max-width: <?php echo $moduleWidth; ?>;
	max-height: <?php echo $moduleHeight; ?>;
	overflow: <?php echo $overflow; ?>;
	padding: <?php echo $modulePadding; ?>;
	margin: <?php echo $moduleMargin; ?>;
	<?php echo ($isBgColor) ? "background-color: {$bgColor};" : '';?>
	<?php echo ($bgImage != '') ? "background: url({$bgImage}) top center repeat;" : ''; ?>
}
#vina-gridgallery-k2-wrapper<?php echo $module->id; ?> .item {
	max-width: <?php echo $itemMaxWidth; ?>px;
}
#vina-gridgallery-k2-wrapper<?php echo $module->id; ?> .item a {
	color: <?php echo $itemLinkColor; ?>;
}
#vina-gridgallery-k2-wrapper<?php echo $module->id; ?> .item .image-block:before {
	<?php echo ($isItemBgColor) ? "border-bottom: 12px solid {$itemBgColor};" : ''; ?>
}
#vina-gridgallery-k2-wrapper<?php echo $module->id; ?> .item .text-block {
	<?php echo ($isItemBgColor) ? "background-color: {$itemBgColor};" : ''; ?>
	color: <?php echo $itemTextColor; ?>;
	padding: <?php echo $itemPadding; ?>;
}
#vina-filter-items<?php echo $module->id; ?> {
	text-align: <?php echo $filterPosition; ?>;
}
#vina-gridgallery-k2-wrapper<?php echo $module->id; ?> .filter-label {
    background-color: <?php echo $buttonColor; ?>;
	color: <?php echo $textColor; ?>;
    margin: <?php echo $buttonsMargin; ?>;
    padding: <?php echo $buttonsPadding; ?>;
}
#vina-gridgallery-k2-wrapper<?php echo $module->id; ?> .filter-label.active,
#vina-gridgallery-k2-wrapper<?php echo $module->id; ?> .filter-label:hover {
    background-color: <?php echo $buttonAColor; ?>;
	color: <?php echo $textAColor; ?>;
}
#vina-gridgallery-k2-wrapper<?php echo $module->id; ?> .tags {
	border-top: 1px solid <?php echo $itemTextColor; ?>;
}
</style>
<div id="vina-gridgallery-k2-wrapper<?php echo $module->id; ?>" class="vina-gridgallery-k2-wrapper">
	<!-- Category Filter Block -->
	<?php if($categoryFilter) : ?>
	<div id="vina-filter-items<?php echo $module->id; ?>">
		<div class="filter-label active" ><?php echo JText::_('VINA_ALL_CATEGORIES'); ?></div>
		<?php for($i = 0; $i < count($categories['cid']); $i++) : ?>
		<div class="filter-label" data-filter=".category-<?php echo $categories['cid'][$i]; ?>">
			<?php echo $categories['cname'][$i]; ?>
		</div>
		<?php endfor; ?>
	</div>
	<?php endif; ?>
	
	<!-- Items Block -->
	<div id="vina-gridgallery-k2<?php echo $module->id; ?>" class="items-block">
		<?php 
			foreach($items as $key => $item) : 
				$image = $item->$itemImgSize;
				$title = $item->title;
				$link  = $item->link;
				$cname = $item->categoryname;
				$clink = $item->categoryLink;
				$hits  = $item->hits;
				$tags  = $item->tags;
				$introtext = $item->introtext;
				$created   = $item->created;
		?>
		<div class="brick item category-<?php echo $item->catid; ?>">
			<!-- Image Block -->
			<?php if($itemImage && !empty($image)) : ?>
			<div class="image-block">
				<a href="<?php echo $link; ?>" title="<?php echo $title; ?>">
					<img src="<?php echo $image; ?>" alt="<?php echo $title; ?>" title="<?php echo $title; ?>" />
				</a>
				<!-- Readmore Block -->
				<div class="action-k2">
					<a class="zoomplus" href="<?php echo $image; ?>" title="<?php echo $title; ?>" data-gallery>
						<i class="fa fa-search"></i>
					</a>
					<?php if($itemReadMore) : ?>
					<a class="readmore" href="<?php echo $link; ?>" title="<?php echo $title; ?>">
						<i class="fa fa-link"></i>
					</a>
					<?php endif; ?>
				</div>
			</div>
			<?php endif; ?>
			
			<!-- Text Block -->
			<?php if($itemTitle || $itemIntroText || $itemCategory || $itemDateCreated || $itemHits || $itemReadMore) : ?>
			<div class="text-block">
				<!-- Title Block -->
				<?php if($itemTitle) :?>
				<h3 class="title">
					<a href="<?php echo $link; ?>" title="<?php echo $title; ?>"><?php echo $title; ?></a>
				</h3>
				<?php endif; ?>
				
				<!-- Info Block -->
				<?php if($itemCategory || $itemDateCreated || $itemHits) : ?>
				<div class="info">
					<?php if($itemAuthor) : ?>
					<span>
						<?php echo JTEXT::_('VINA_AUTHOR'); ?>:
						<a rel="author" title="<?php echo K2HelperUtilities::cleanHtml($item->author); ?>" href="<?php echo $item->authorLink; ?>"><?php echo $item->author; ?></a>
					</span>
					<?php endif; ?>
					
					<?php if($itemDateCreated) : ?>
					<span><?php echo JTEXT::_('VINA_PUBLISHED'); ?>: <?php echo JHTML::_('date', $created, 'F d, Y');?></span>
					<?php endif; ?>
					
					<?php if($itemCategory) : ?>
					<span><?php echo $cname; ?></span>
					<?php endif; ?>
					
					<?php if($itemHits) : ?>
					<span><?php echo JTEXT::_('VINA_HITS'); ?>: <?php echo $hits; ?></span>
					<?php endif; ?>
				</div>
				<?php endif; ?>
				
				<!-- Intro text Block -->
				<?php if($itemIntroText && !empty($introtext)) : ?>
				<div class="introtext"><?php echo $introtext; ?></div>
				<?php endif; ?>
				
				<!-- Tags Block -->
				<?php if($itemTags & count($tags)) : ?>
				<div class="tags">
					<span><?php echo JText::_('VINA_TAGS'); ?>:</span>
					<?php foreach($tags as $tag): ?>
						<a href="<?php echo $tag->link; ?>"><?php echo $tag->name; ?></a>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>
			</div>
			<?php endif; ?>
		</div>
		<?php endforeach; ?>
	</div>
</div>
<script type="text/javascript">
jQuery(document).ready(function ($) {
	var wall = new freewall("#vina-gridgallery-k2<?php echo $module->id; ?>");
	wall.reset({
		selector	: '.brick',
		draggable	: <?php echo $draggable ? 'true' : 'false'; ?>,
		animate		: <?php echo $animate ? 'true' : 'false'; ?>,
		cache		: <?php echo $moduleCache ? 'true' : 'false'; ?>,
		cellW		: function(width) {
			var cellWidth = width / <?php echo $maxItemRow; ?>;
			cellWidth = (cellWidth < <?php echo $itemMinWidth; ?>) ? <?php echo $itemMinWidth; ?> : cellWidth;
			return cellWidth - <?php echo $gutterX + $gutterY; ?>;
		},
		cellH		: 'auto',
		delay		: <?php echo $delay; ?>,
		fixSize		: <?php echo $fixSize; ?>,
		gutterX		: <?php echo $gutterX; ?>,
		gutterY		: <?php echo $gutterY; ?>,
		rightToLeft	: <?php echo ($rightToLeft) ? 'true' : 'false'; ?>,
		bottomToTop	: <?php echo ($bottomToTop) ? 'true' : 'false'; ?>,
		onResize	: function() {
			wall.fitWidth();
		}
	});
	
	<?php if($categoryFilter) : ?>
	$("#vina-filter-items<?php echo $module->id; ?> .filter-label").click(function() {
		$("#vina-filter-items<?php echo $module->id; ?> .filter-label").removeClass("active");
		var filter = $(this).addClass('active').data('filter');
		if(filter) {
			wall.filter(filter);
		}
		else {
			wall.unFilter();
		}
	});
	<?php endif; ?>
	
	wall.fitWidth();
	
	$(window).load(function(){
		wall.fitWidth();
	});
});
</script>